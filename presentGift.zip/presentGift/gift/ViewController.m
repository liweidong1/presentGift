//
//  ViewController.m
//  gift
//
//  Created by liweidong on 17/6/12.
//  Copyright © 2017年 Sillen. All rights reserved.
//

#import "ViewController.h"
#import "PresentView.h"
#import "PresentModel.h"
#import "CustonCell.h"

@interface ViewController ()<PresentViewDelegate>
- (IBAction)giftOne:(id)sender;
- (IBAction)giftTwo:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *giftOne;
@property (weak, nonatomic) IBOutlet UIButton *giftTwo;

@property (nonatomic, strong) PresentView *presentView;
@property (strong, nonatomic) NSMutableArray *dataArray;

@property (assign, nonatomic)NSInteger number;
@end

@implementation ViewController
- (NSMutableArray *)dataArray
{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
        PresentModel *one = [PresentModel modelWithSender:@"one" giftName:@"小车" icon:@"icon1" giftImageName:@"prop_b"];
        [_dataArray addObject:one];
        PresentModel *two = [PresentModel modelWithSender:@"two" giftName:@"蘑菇" icon:@"icon2" giftImageName:@"prop_g"];
        [_dataArray addObject:two];
    }
    return _dataArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    PresentView *presentView = [[PresentView alloc]initWithFrame:CGRectMake(0, 200, self.view.bounds.size.width/2, 250)];
    [self.view addSubview:presentView];
    presentView.backgroundColor = [UIColor grayColor];
    _presentView = presentView;
    


    self.presentView.delegate = self;
    [self setupSerialBtn:self.giftOne];
    [self setupSerialBtn:self.giftTwo];
    
    self.number = 5;

}
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    
    //连送
    //模拟当前连乘动画展示到5的时候才加入聊天室(连乘动画从5开始)
    PresentModel *model = [PresentModel modelWithSender:@"one" giftName:@"小车" icon:@"icon1" giftImageName:@"prop_b"];
    model.giftNumber = ++self.number;
    [self.presentView insertPresentMessages:@[model] showShakeAnimation:YES];
}


#pragma mark - Private

- (void)setupSerialBtn:(UIButton *)btn
{
    btn.adjustsImageWhenHighlighted = NO;
    btn.clipsToBounds               = YES;
    btn.layer.cornerRadius          = CGRectGetWidth(btn.frame) * 0.5;
}
#pragma mark - PresentViewDelegate

- (PresentViewCell *)presentView:(PresentView *)presentView cellOfRow:(NSInteger)row
{
    return [[CustonCell alloc] initWithRow:row];
}

- (void)presentView:(PresentView *)presentView configCell:(PresentViewCell *)cell model:(id<PresentModelAble>)model
{
    CustonCell *customCell = (CustonCell *)cell;
    customCell.model = model;
}

- (void)presentView:(PresentView *)presentView didSelectedCellOfRowAtIndex:(NSUInteger)index
{
    CustonCell *cell = [presentView cellForRowAtIndex:index];
    NSLog(@"你点击了：%@", cell.model.giftName);
}

- (void)presentView:(PresentView *)presentView animationCompleted:(NSInteger)shakeNumber model:(id<PresentModelAble>)model
{
    self.number = 5;
    NSLog(@"%@礼物的连送动画执行完成", model.giftName);
}

- (IBAction)giftOne:(id)sender {
    [self.giftOne setTitle:@"30" forState:UIControlStateNormal];
    [self.presentView insertPresentMessages:@[self.dataArray[0]] showShakeAnimation:YES];
}
- (IBAction)giftTwo:(id)sender {
    [self.giftTwo setTitle:@"30" forState:UIControlStateNormal];
    [self.presentView insertPresentMessages:@[self.dataArray[1]] showShakeAnimation:YES];
}
@end
