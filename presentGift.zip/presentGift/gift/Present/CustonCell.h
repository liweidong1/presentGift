//
//  CustonCell.h
//  PresentDemo
//
//  Created by siping ruan on 16/10/9.
//  Copyright © 2016年 阮思平. All rights reserved.
//

#import "PresentViewCell.h"

@class PresentModel;
@interface CustonCell : PresentViewCell

@property (strong, nonatomic) PresentModel *model;

@end
